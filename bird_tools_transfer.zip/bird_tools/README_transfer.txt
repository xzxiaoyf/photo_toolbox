鸟类照片识别工具 —— 跨机器移植说明
=====================================

一、这个包里有什么
------------------
bird_scanner.py     批量识别程序（GUI + --cli 命令行两种用法）
bird_id_models/     模型与数据（49MB，共 5 个文件，必须一起拷）
requirements.txt    Python 依赖清单
README_transfer.txt 本文件

这个包只装「要跑 AI 识别所必需的东西」，45MB 基本都是模型权重。
另外两个小工具既不读模型也不依赖模型文件夹，已单独放在
photo_tools_light.zip 里（几百 KB），需要时再拷，不要混进这个包：

  photo_track_map_v3.py          照片轨迹地图（纯标准库，零依赖）
  heic_to_jpg_converter_gui.py   HEIC/HIF 转 JPG

二、重要：模型不会自动下载
--------------------------
bird_scanner.py 内含 AI 模型的完整推理代码，但模型权重（49MB）
不会自动下载，也不会联网获取。程序启动时只在本地按以下顺序找
bird_id_models/ 文件夹：

  1. bird_scanner.py 所在的目录
  2. 运行命令时所在的当前目录
  3. （开发者本机的备用路径，新机器上无效，可忽略）

所以：把 bird_scanner.py 和 bird_id_models/ 放在同一个目录下即可，
无需联网，永久离线可用。

三、新机器部署步骤
------------------
第 1 步  安装 Python 3.10 以上版本（建议 3.12）
         注意选上 tkinter（Windows/macOS 官方安装包默认自带）

第 2 步  建虚拟环境并安装依赖（联网一次，之后即可离线）
         python -m venv .venv
         # macOS / Linux:
         .venv/bin/pip install -r requirements.txt
         # Windows:
         .venv\Scripts\pip install -r requirements.txt

         国内网络慢可加镜像：
         pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

第 3 步  运行
         # 图形界面（选目录 -> 提交）
         python bird_scanner.py
         # 命令行静默批量扫描
         python bird_scanner.py --cli "照片目录路径"

四、想只用地图工具？
--------------------
photo_track_map_v3.py 不读模型、不需要 bird_id_models/，也不依赖
requirements.txt 里的任何包（纯标准库），所以在 photo_tools_light.zip
里而不是本包。单独拷它过去，配合照片旁边的 *.bird.json 边车文件，
就能显示鸟种和画识别框——前提是那批照片已经用 bird_scanner.py
扫描过（边车文件是识别产物，不会自动生成）。

同理，HEIC/HIF 转 JPG 用的 heic_to_jpg_converter_gui.py 也在那个
轻量包里，用法见其附带的 README_light.txt。

五、常见问题
------------
Q: 报 NoSuchFile: ...yolo_bird_detect.onnx
A: bird_id_models 文件夹没拷过去。程序只按上面第二节的顺序找本地
   模型；把整个文件夹拷到 bird_scanner.py 旁边即可。

Q: 报 ModuleNotFoundError: No module named 'onnxruntime'
A: 虚拟环境里没装依赖，执行第 2 步。

Q: 输出里写「中国分布校正: 关闭（缺名录文件）」
A: bird_id_models/china_birds_v10.txt 丢了。程序仍能识别，但少了
   「把非中国分布种纠正为中国近似种」的能力，误判会变多。

Q: Sony 相机的 .HIF（HEIF）照片显示「读不了图」
A: 缺 pillow-heif 包。HEIF 格式 OpenCV 不支持，程序会自动回退到
   pillow_heif 解码（requirements.txt 已包含，重装依赖即可）。
   没装该包时 JPEG/PNG 照常工作，只有 HIF/HEIC 受影响。

Q: Windows 上路径写不好
A: 图形界面点「选择照片目录」直接选即可，支持中文路径。

六、关于模型文件的通用性
------------------------
模型是标准 ONNX 格式，Mac 上生成的权重在 Windows / Linux 上可直接
加载，无需转换。唯一要求是新机器装对应平台的 onnxruntime。
